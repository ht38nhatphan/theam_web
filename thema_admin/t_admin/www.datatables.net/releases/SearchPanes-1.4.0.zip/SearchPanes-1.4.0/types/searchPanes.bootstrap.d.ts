/*! Bootstrap integration for DataTables' SearchPanes
 * ©2016 SpryMedia Ltd - datatables.net/license
 */
declare let define: {
    amd: string;
    (stringValue: any, Function: any): any;
};
