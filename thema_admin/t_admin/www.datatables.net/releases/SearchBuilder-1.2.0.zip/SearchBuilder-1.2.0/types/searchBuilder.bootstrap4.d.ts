/*! Bootstrap 4 ui integration for DataTables' SearchBuilder
 * ©2016 SpryMedia Ltd - datatables.net/license
 */
declare let define: {
    amd: string;
    (stringValue: any, Function: any): any;
};
